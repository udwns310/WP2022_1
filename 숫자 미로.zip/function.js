function init(){
    for(i=0; i<1000; i++){
        move((Math.floor(Math.random()*16)));
    }
}

function move(n){
    if(n > 3) tryMove(n, n-4);
    if(n % 4 != 0) tryMove(n, n-1);
    if(n % 4 != 3) tryMove(n, n+1);
    if(n < 12) tryMove(n, n+4);
}

function tryMove(from, to){
    var s = document.getElementById("cell" + from);
    var d = document.getElementById("cell" + to);
    if(d.value == " "){
        d.value = s.value;
        s.value = " ";
    }
}