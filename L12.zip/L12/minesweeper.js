function leftClick(element, id) {
    if(isGameEnd==true) return;
    console.log("left mouse button clicked");
    const i = parseInt(id / width);
    const j = id % width;
    let ii, jj;
    if (isStarted == false) {
        for (let p = 0; p < nBombs; p++) { //nbombs는 99
            ii = i; jj = j;
            
            while ((ii - i) * (ii - i) < 2 && (jj - j) * (jj - j) < 2 && cells[ii * width +jj] == 0 ) {
                ii = Math.floor((Math.random() * height));
                jj = Math.floor((Math.random() * width));
            }
            if(cells[ii * width + jj] == 1){
                p--;
            }
            else {
            document.getElementById(String(ii * width + jj)).style.backgroundColor = 'black'; //폭탄 위치 보여주기
            cells[ii * width + jj] = 1;
            }
        }
        myInterval = setInterval(timeCount, 1000);
        isStarted = true;
    }
    openCells(i, j);
}//

function rightClick(element, id){
    if(isGameEnd==true) return;
    console.log("right mouse button clicked");
    if(remainBombs==0 && checked[id]==0) return;
    const i = parseInt(id / width);
    const j = id % width;
    if(checked[id]==1){
        checked[id] = 0;
        remainBombs++;
        document.getElementById(String(i * width + j)).style.backgroundColor = '#BDBDBD';
        document.getElementById(String(i * width + j)).innerHTML = ''
        
    } else {
        checked[id]=1;
        remainBombs--;
        //document.getElementById(String(i * width + j)).style.backgroundColor = 'orange';
        
        document.getElementById(String(i * width + j)).innerHTML = '<img id=flag src="flag.png">'
        
    }
        document.getElementById('bomb').innerHTML = leadingZeros(remainBombs, 3);
}//



function openCell(i, j) {
    let id = i * width + j;
    bombs = bombCount(i,j);
    extBombCount = "<span class='count cnt" + bombs + "'>" + (bombs?bombs:"") + "</span>";

    document.getElementById(String(id)).className = 'cellOpen';
    document.getElementById(String(id)).innerHTML = extBombCount;
}// 

function openCells(p,q){
    let visited = Array(arraySize);
    visited.fill(0);
    let queue = Array(arraySize);
    queue.fill(0);
    front =0;
    rear = 0;
    function deq(){
        return queue[front++];
    }
    function enq(id){
        queue[rear++] = id;
    }
    let i = p;
    let j = q;
    let ii;
    let jj;

    let id = i * width + j;
    if(cells[id] == 2) return;
        if(checked[id]==1) return;
    if(cells[id] == 1){
        //document.getElementById(String(id)).style.backgroundColor = 'red';  
        gameOver();
        document.getElementById(String(id)).innerHTML = '<img id=flag src="redbomb.png">'
        return;
    }
    
    openCell(i, j);
    if (visited[id] == 0 && bombCount(i, j) ==0){
        enq(i * width +j);
    }
    visited[i * width + j] = 1;
    while(front != rear) {
        id = deq();
        i = parseInt(id/width);
        j = id % width;
        openCell(i,j);
        for(let k =0; k<8; k++){
            ii = i + neighbor[k][0];
            jj = j + neighbor[k][1];
            if( ii<0 || 16 <= ii) continue;
            if(jj<0 || 30 <= jj) continue;
            openCell(ii,jj);
            iidd= ii * width + jj;
            if(visited[iidd] ==0 && bombCount(ii, jj) ==0){
                enq(iidd);
            }
            visited[iidd] = 1;

        }
    }
    for(let i =0; i<height; i++){
        for(let j = 0; j<width; j++){
            id = i * width + j;
            if(cells[id] == 1 )return;
            if(document.getElementsByClassName("cellOpen").length == nOpenCells ) {
                gameOver();
            }
            //폭탄을 제외한 모든 셀이 열렸을 때 
            //게임 중지, 시간 멈춤, 폭탄 표시, 리셋이미지 변경, 이벤트 중지
        }
    }
    gameOver();
}//


function gameOver(){
    isGameEnd=true;
    clearInterval(myInterval);
    if(document.getElementsByClassName("cellOpen").length == nOpenCells) {
        document.getElementById("rst").src = "good.png";
    }
    else{
        document.getElementById("rst").src = "ddead.png";
    }
    
    for(let i=0;i<height;i++){
        for(let j=0;j<width;j++){
            id=i*width+j;
            if(cells[id]==1 && checked[id] == 0){
                //document.getElementById(String(id)).innerHTML="<span class='bomb'>💣</span>";
                document.getElementById(String(id)).className = 'bombCell';
                
                document.getElementById(String(id)).innerHTML = '<img id=flag src="bomb.png">'
            }
            if(cells[id]==0 && checked[id]==1){
                //document.getElementById(String(id)).style.backgroundColor='red';
                //document.getElementById(String(id)).innerHTML="<span class='bomb cnt7'>💥</span>"
                document.getElementById(String(id)).className = 'bombCell';
                document.getElementById(String(id)).innerHTML = '<img id=flag src="xbomb.png">'
            }
        }
    }
    

    
}//

function timeCount() {
    curTime++;
    document.getElementById('time').innerHTML = leadingZeros(curTime, 3)
    if(curTime == 999){
        gameOver();
    }
}//

function leadingZeros(n, digits) {
    var zero = '';
    n = n.toString();
    if (n.length < digits) {
        for (var i = 0; i < digits - n.length; i++) {
            zero += 0;
        }
    }
    return zero + n;
}//

function bombCount(i, j) {
    let bombCount = 0;
    let ii;
    let jj;
    for (let k = 0; k < 8; k++) {
        ii = i + neighbor[k][0];
        jj = j + neighbor[k][1];
        if (ii < 0 || ii >= height) continue;
        if (jj < 0 || jj >= width) continue;
        if (cells[ii * width + jj] == 1) bombCount++;
    }
    return bombCount;
}//

function checkCount(i ,j){
    let checks = 0;
    let ii;
    let jj;
    for (let k = 0; k < 8; k++) {
        ii = i + neighbor[k][0];
        jj = j + neighbor[k][1];
        if (ii < 0 || ii >= height) continue;
        if (jj < 0 || jj >= width) continue;
        if (cells[ii * width + jj] == 1) checks++;
    }
    return checks;
}

/*function bothDown(element, id){
    if(isGameEnd==true) return;
    savedId = id;
    const i = parseInt(id/width);
    const j = id % width;
    let ii;
    let jj;
    for(let k=0; k<8; k++){
        ii = i + neighbor[k][0];
        jj = j + neighbor[k][1];
        if(ii < 0 || height <= ii) continue;
        if(jj < 0 || width <= jj) continue;
        let iidd = ii * width + jj;
        if(cells[iidd] < 2 && checked[iidd] == 0 ) document.getElementById(String(iidd)).className = 'cellOpen';
    }
    if(cells[id] < 2 && chekced[id] == 0) document.getElementById(String(id)).className = 'cellOpen';
}

function bothUp(element, id){
    if(isGameEnd==true) return;
    console.log("both mouse button clicked");
    const i = parseInt(id/width);
    const j = id % width;
    let ii;
    let jj;
    for(let k=0; k<8; k++){
        ii = i + neighbor[k][0];
        jj = j + neighbor[k][1];
        if(ii < 0 || height <= ii) continue;
        if(jj < 0 || width <= jj) continue;
        let iidd = ii * width + jj;
        if(cells[iidd] < 2 && checked[iidd] == 0 ) document.getElementById(String(iidd)).className = 'cellClosed';
    }
    if(cells[savedId] < 2 && checked[savedId] == 0) document.getElementById(String(savedId)).className = 'cellClosed';
    //그대로 다시 닫는 코드


    if(cells[savedId] == 2 && bombCount(i,j) == checkCount(i, j)){
        for(let k=0; k<8; k++){
            ii = i + neighbor[k][0];
            jj = j + neighbor[k][1];
            if(ii < 0 || height <= ii) continue;
            if(jj < 0 || width <= jj) continue;
            if(checked[ii * width + jj] == 0 && cell[ii * width + jj] == 0) openCells(ii, jj);
            bombCount(ii, jj);
        }    
    }
}//*/

function mouseDown(e, element, id){
    console.log("Down " + e.button + " " + leftMB + " " + rightMB);
    if(e.button ==0) {
        leftMB =true;
        document.getElementById("rst").src = "surprise.png";
        if(rightMB == true) bothDown(element, id);   
    }
    else if (e.button ==2) {
        if(leftMB == true) bothDown(element, id);
        rightMB = true;
    }
}//

function mouseUp(e, element, id){
    console.log("Up " + e.button + " " + leftMB + " " + rightMB);
    if(bothMB) {
        document.getElementById("rst").src = "smile.png";
        leftMB = false;
        rightMB = false;
        bothMB = false;
        return;
    }
    if(e.button == 0) {
        document.getElementById("rst").src = "smile.png";
        if(rightMB == false) leftClick(element, id);
        
        else{
            bothMB = true;
            bothUp(element, id);
        }
        leftMB =false;
    }
    else if(e.button == 2){
        document.getElementById("rst").src = "smile.png"; 
        if(leftMB == false) rightClick(element, id);
        else{
            bothMB = true;
            bothUp(element, id);
        }
        rightMB = false;
    }
}//

function doNothing(e){
    e.preventDefault();
}//

function resetButton(){
    location.reload(true);
    /*isStarted = false;
    isGameEnd = false;

    remainBombs = 99;
    curTime = 0;

    leftMB = false;
    rightMB = false;
    bothMB = false;
    savedId = 16 * 30 + 1;

    cells.fill(0);
    checked.fill(0);
    clearInterval(myInterval);

    for(let i = 0; i < height; i++) {
        for(let j = 0; i < widht; j++){
            id = i * width + j;
            document.getElementById(String(id)).classname = 'cellClosed';
            document.getElementById(String(id)).innerHTML = "";
            document.getElementById(String(id)).style.backgroundColor = '#BDBDBD'
        }
    }*/
    
}