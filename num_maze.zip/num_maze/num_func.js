function init() {
    isGameon = false;
    document.getElementById("message").innerHTML = "0";
    for (let i=0; i<1000; i++) move((Math.floor(Math.random()*size*size)));
    myInterval = setInterval(timeCount, 1000);
    isGameon = true;
}
function move(n) {
    if(n > (size-1)) tryMove(n, n-size);
    if(n % size != 0) tryMove(n, n-1);
    if(n % size != (size-1) ) tryMove(n, n+1);
    if(n < size * (size-1) ) tryMove(n, n+size);
    if(!isGameon) return;

    let countnum = document.getElementById("message").innerHTML;
    countnum++;
    document.getElementById("message").innerHTML = countnum;
    for(i=0; i< size * size -1; i++){
        if(document.getElementById("cell" + i).value != i+1) break;
    }
    if(i == size*size -1) GameOver();
}
function tryMove(from, to) {
    var s = document.getElementById("cell" + from);
    var d = document.getElementById("cell" + to);
    if(d.value == " "){
        d.value = s.value;
        s.value = " ";
    }
}
function GameOver(size) {
    isGameon = false;
    document.getElementById("message").innerHTML += "Clear!";
}
function drawBoard(size) {
    let str = "";
    for(let i=0; i<size; i++) {
        for (let j=0; j<size; j++) {
            const id = i*size+j;
            const val = id+1
            str += "<input type=button id='cell" + id + "' ";
            str += "class='cbutton' ";
            str += "value='" + (val<size*size ? val : " ") + "' ";
            str += "onclick='move(" + id + ");'>";
        }
        str += "<br/>";
    }
    document.getElementById("board").innerHTML = str;
}
function setSize(_size) {
    size = parseInt(_size);
    drawBoard(size);
    init();
}
function solve() {
}

function timeCount() {
    curTime++;
    document.getElementById('time').innerHTML = leadingZeros(curTime, 3)
}